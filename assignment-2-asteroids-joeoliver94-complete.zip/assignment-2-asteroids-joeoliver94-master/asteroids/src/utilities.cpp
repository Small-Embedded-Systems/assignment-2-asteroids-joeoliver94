/* 
	 Utilities Code File - Joe Oliver and Jo Larby
*/

#include <stdlib.h>
#include <stdint.h>
#include <math.h>

/*
	Small useful functions which don't fit elsewhere
*/

int randomTravel(int from, int to){
	int range = to - from;
	return rand()%range + from;
}

float radians(float a){
	const float pi = 3.141592;
	return a * pi /180.0f;
}
