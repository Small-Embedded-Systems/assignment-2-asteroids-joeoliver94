/* 
	 Drawing Header File - Joe Oliver and Jo Larby
	 The Drawing header file holds information for the creation of the shield, asteroids and missiles.
	 The strength of the shield is determined within the shield method. 
*/
void draw(void);
void createMissiles(struct missile * lst);
void createAsteroids(struct asteroid * lst);
void shield(void);
void swapBuffers(void);
void startDoubleBuffering(void);
void drawBitmap(void);
void gameOver(void);
void screen(void);
