/* 
	 Utilities Header File - Joe Oliver and Jo Larby
	 The Utilities header file allows the asteriods to show on the display randomly.
*/

/*
	How far the asteroids can travel on the display
*/
int randomTravel(int from, int to);

/*
	How the asteroids travel on the display
*/
float radians(float a);
