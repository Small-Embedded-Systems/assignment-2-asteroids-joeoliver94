/* 
	 Physics Code File - Joe Oliver and Jo Larby
*/

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <display.h>
#include <mbed.h>
#include <utilities.h>
#include <controls.h>
#include <physics.h>

/*
	Variables declared
*/
static const int heapsize = 5;
static const int asteroidHeapsize = 9;
static node_t heap[heapsize];
static asteroid_t asteroidheap[asteroidHeapsize];
static node_t * freeNodes;
static asteroid_t * asteroidFreeNodes;

float originX;
float originY;
int headingAngle;
float headingAngleRadians;
float pointX;
float pointY;
float leftX;
float leftY;
float rightX;
float rightY;
double score;
int lives;
double speed;
int shieldStrength;
int finalScore;

double accel;
int activeTime;
int activeTimeTotal;
int invincibility;

static const float Dt = 0.01;
struct missile * active = NULL;
struct asteroid * asteroidactive = NULL;

/*
	Physics engine attached to model ticker
*/
void physics(void){
    checkShipStrength(asteroidactive);
    checkMissileHit(active, asteroidactive);
    update(active);
    renewAsteroid(asteroidactive);
    wrapAround();
    headingAngleRadians = radians(headingAngle);
    pointX = 10 * (cos(headingAngleRadians));
  	pointY = 10 * (sin(headingAngleRadians));
  	leftX = ( -5 * (cos(headingAngleRadians))) - ( 5 * (sin(headingAngleRadians)));
  	leftY = ( -5 * (sin(headingAngleRadians))) + ( 5 * (cos(headingAngleRadians)));
  	rightX = ( -5 * (cos(headingAngleRadians))) - ( -5 *(sin(headingAngleRadians)));;
  	rightY = ( -5 * (sin(headingAngleRadians))) + ( -5 * (cos(headingAngleRadians)));;
  	originX = originX + speed * (cos(headingAngleRadians));
  	originY = originY + speed * (sin(headingAngleRadians));
	  score++;
		if( speed < 5 ){
			speed = speed + accel;
		}
		if( accel > 0 ){
			accel = accel - 0.1;
		}
		if( speed > 0 ){
			speed = speed - 0.01;
		}
		time();
		if( invincibility > 0 ){
			invincibility--;
		}
}

/*
	Initial values when the game is started
*/
void initialValues(void){
	originX = 240;
	originY = 130;
	headingAngle = 90;
	score = 0.0;
	shieldStrength=3;
	finalScore = 0;
	accel = 0.0;
	invincibility = 100;
}

/*
	Checks the strength of the shield when hit by an asteroid 
*/
void checkShipStrength(struct asteroid * c){
    for( ; c ; c = c->next ) {
        if(c->asteroidX<(originX + 8) && c->asteroidX>(originX - 8)){
          if(c->asteroidY<(originY + 8) && c->asteroidY>(originY - 8)){
            if(shieldStrength > 0){
							if(invincibility == 0){
								shieldStrength--;
								invincibility = 50;
							}
						} else if(shieldStrength <= 0){
							if(invincibility == 0){
								if(lives > 0){
									lives--;
								}
								originX = 240;
								originY = 130;
								headingAngle = 90;
								speed = 0;
								activeTimeTotal = activeTimeTotal + activeTime;
								score = 0;
								invincibility = 50;
							}
						}
          }
        }
    }
}

/*
	Missile code  
*/
void checkMissileHit(struct missile * a, struct asteroid * b) {
  for(; a ; a = a->next){
    for(; b ; b = b->next){
      if(a->x > (b->asteroidX - 12) && a->x < (b->asteroidX + 12)){
        if(a->y > (b->asteroidY - 12) && a->y < (b->asteroidY + 12)){
          a->ttl = 0;
          b->asteroidTtl = 0;
        }
      }

      }
    }
 }

/*
	Check to see if the missiles have hit the asteroid. 
*/
 void update(struct missile * l){
    for( ; l ; l = l->next ) {
        l->x += l->v_x * Dt;
        l->y += l->v_y * Dt;
        if( l->x <0 || 480 <l->x ) l->ttl=0;
        if( l->y<10 || 260 <l->y ) l->ttl=0;
        l->ttl -= Dt;
        if( l-> next->ttl <= 0 ) {
            struct missile * expired = l-> next;
            l->next = l->next->next;
            freeNode(expired);
        }
    }
}

void renewAsteroid(struct asteroid * l){
    for( ; l ; l = l->next ) {
        l->asteroidX += l->asteroidV_x * Dt;
        l->asteroidY += l->asteroidV_y * Dt;
        if( l->asteroidX<-20 || 500<l-> asteroidX ) l->asteroidTtl=0;
        if( l->asteroidY<25 || 280<l-> asteroidY ) l->asteroidTtl=0;
        l->asteroidTtl -= Dt;
        if( l->next->asteroidTtl <= 0 ) {
            struct asteroid * expired = l-> next;
            l->next = l->next->next;
            asteroidFreeNode(expired);
        }
    }
}

void wrapAround(void){
  if(originX > 480){
		originX = 5;
	} else if(originX < 0){
		originX = 475;
	} else if(originY > 260){
		originY = 25;
	} else if(originY < 20){
		originY = 255;
	}
}
/*
	The score calculated by the time in play.
*/
void time(void){
	activeTime = (int)((score/100) + 0.5);
}

/*
	Missiles : when they are released, how far and fast they continue on the screen and in what direction 
*/
void strike(struct missile * r){
    r->x = originX;
    r->y = originY;
    r->v_x = 200 * (cos(headingAngleRadians));
    r->v_y = 200 * (sin(headingAngleRadians));
    r->ttl = 200;
}

/*
	Asteroids : range on screen 
*/
void strike(struct asteroid * r){
    r->asteroidX = randomTravel(10,470);
    r->asteroidY = randomTravel(10,250);
    r->asteroidV_x = randomTravel(-5,5);
    r->asteroidV_y = randomTravel(-5,5);
    r->asteroidTtl = randomTravel(900,1100);
}

/*
	Active missile system 
*/
void missileSystem(void){
        struct missile * spark = allocnode();
        if(spark) {
            spark->next = active;
            active = spark;
            strike(spark);
        }
}
/*
	Asteroids : determines if they are active on the display
*/
void asteroidSystem(void){
        struct asteroid * asteroidspark = asteroidallocnode();
        if(asteroidspark) {
            asteroidspark->next = asteroidactive;
            asteroidactive = asteroidspark;
            strike(asteroidspark);
        }
}

void loadHeap(void){
    int n;
    for( n=0 ; n<(heapsize - 1) ; n++) {
        heap[n].next = &heap[n+1];
    }
    heap[n].next = NULL;
    freeNodes = &heap[0];
}

/*
	Total number of Asteroids displayed
*/
void loadAsteroidHeap(void){
    int n;
    for( n = 0 ; n<(asteroidHeapsize - 1) ; n++) {
        asteroidheap[n].next = &asteroidheap[n + 1];
    }
    asteroidheap[n].next = NULL;
    asteroidFreeNodes = &asteroidheap[0];
}

node_t * allocnode(void){
    node_t * node = NULL;
    if( freeNodes ) {
        node = freeNodes;
        freeNodes = freeNodes->next;
    }
    return node;
}

asteroid_t * asteroidallocnode(void){
    asteroid_t * node = NULL;
    if( asteroidFreeNodes ) {
        node = asteroidFreeNodes;
        asteroidFreeNodes = asteroidFreeNodes->next;
    }
    return node;
}

void freeNode(node_t * n){
    n->next = freeNodes;
    freeNodes = n;
}

void asteroidFreeNode(asteroid_t * n){
    n->next = asteroidFreeNodes;
    asteroidFreeNodes = n;
}
