/* 
	 Physics Header File - Joe Oliver and Jo Larby
	 The Physics header file holds information for the creation of the asteroids and missiles.
	 It holds the code which will develop as the behaviour of both the asteroids and missiles.
*/

/*
	Missiles struct code:
	The velocity of a travelling missile is written as v_x, v_y.
	ttl determines how the missiles will travel on the display once they have been fired.
	struct missile *next defines the next missile fired until other action takes place.	
*/
typedef struct missile {
    float x,y;
    float v_x, v_y;
    float ttl;
    struct missile *next;
} node_t;

/*
	Asteroid struct code:
	The velocite of a travelling asteroid is written as asteroidV_x, asteroidV_y.
	asteroidTtl determines how the asteroids will travel on the display when created.
	struct asteroid *next defines the next asteroid that can be created and shown on the display.	
*/
typedef struct asteroid {
    float asteroidX,asteroidY;
    float asteroidV_x, asteroidV_y;
    float asteroidTtl;
    struct asteroid *next;
} asteroid_t;

/* 
	Variables being defined for the ship
*/
extern float originX;
extern float originY;
extern int headingAngle;
extern float headingAngleRadians;
extern float pointX;
extern float pointY;
extern float leftX;
extern float leftY;
extern float rightX;
extern float rightY;
extern double score;
extern struct missile *active;
extern struct asteroid *asteroidactive;
extern int lives;
extern double speed;
extern int shieldStrength;
extern int finalScore;
extern double accel;
extern int activeTime;
extern int activeTimeTotal;
extern int invincibility;
extern const int heapsize;
extern const int asteroidHeapsize;

/*
	Variables being defined for the physics of the asteroids and missiles
*/
void physics(void);
void checkShipStrength(struct asteroid * c);
void checkMissileHit(struct missile *a, struct asteroid * b);
void update(struct missile * l);
void renewAsteroid(struct asteroid * l);
void wrapAround(void);
void time(void);
void strike(struct missile * r);
void strike(struct asteroid * r);
void missileSystem(void);
void asteroidSystem(void);
void loadHeap(void);
void loadAsteroidHeap(void);
node_t *allocnode(void);
asteroid_t *asteroidallocnode(void);
void freeNode(node_t * n);
void asteroidFreeNode(asteroid_t * n);
void initialValues(void);
