/* 
	 Main Code File - Joe Oliver and Jo Larby
*/

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <display.h>
#include <mbed.h>
#include <utilities.h>
#include <controls.h>
#include <physics.h>
#include <drawing.h>

Ticker drawing;
Ticker model;
Ticker controller;
Ticker asteroids;
static const float Dt = 0.01;
static const float drawTick = 0.025;
static const float controlTick = 0.1;
static const float asteroidTick = 0.1;

#define initialLives 5

/*
	Main Function with initialisation
	Four ticker objects are used within the main. These are for
	drawing on the display, the physics, controller and asteroids being created.
*/

int main(){
    loadHeap();
    loadAsteroidHeap();
    startDoubleBuffering();
		initialValues();
		lives = initialLives;
		drawing.attach(draw, drawTick);
		model.attach(physics, Dt);
		controller.attach(controls, controlTick);
		asteroids.attach(asteroidSystem, asteroidTick);
		while(1){
		if(lives == 0){
			drawing.detach();
			model.detach();
			controller.detach();
			asteroids.detach();
			gameOver();
			if(playGameAgain()){
				screen();
				finalScore = 0;
				activeTimeTotal = 0;
				initialValues();
				lives = initialLives;
				drawing.attach(draw, 0.025);
				model.attach(physics, Dt);
				controller.attach(controls, 0.1);
				asteroids.attach(asteroidSystem, 0.1);
			}
		}
	}
}
