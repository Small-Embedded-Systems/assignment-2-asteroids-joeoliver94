/* 
	 Controls Code File - Joe Oliver and Jo Larby
*/

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <display.h>
#include <mbed.h>
#include <physics.h>
#include <controls.h>

/*
	Joystick movement inputs 
*/

enum position { JLEFT,JDOWN,JRIGHT,JUP,JCENTRE};
DigitalIn buttons[] = {P5_0, P5_1, P5_4, P5_2, P5_3};

/*
	Controls for the joystick : maximum speed travelled by the ship is 2
*/

#define turnPoint 9
#define accMax 2
#define accInc 0.2

void controls(void){
  if(buttonPressed(JLEFT)){
    headingAngle = headingAngle + turnPoint;
  } else if(buttonPressed(JRIGHT)){
    headingAngle = headingAngle - turnPoint;
  } else if(buttonPressed(JUP)){
		if(accel < accMax){
			accel = accel + accInc;
		}
  }
	if(buttonPressed(JCENTRE)){
		missileSystem();
  }
}

/*
	More joystick controls : playing the game again after game over
*/
bool playGameAgain(void){
	if(lives == 0 && buttonPressed(JCENTRE)){
		return true;
	}
	return false;
}

bool buttonPressed(enum position p){
    return !buttons[p];
}
