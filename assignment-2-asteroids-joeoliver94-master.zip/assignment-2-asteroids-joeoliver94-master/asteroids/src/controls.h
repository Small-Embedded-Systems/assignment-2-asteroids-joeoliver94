/* 
	 Controls Header File - Joe Oliver and Jo Larby
	 The Controls header file holds information for the creation of the shield, asteroids and missiles.
	 The strength of the shield is determined within the shield method. 
*/

void controls(void);
bool buttonPressed(enum position p);
bool playGameAgain(void);
